// Tansk # 01
#include <iostream>
using namespace std;
int main()
{
	cout << "Hello World" << endl;
	cout << "University Of Central Punjab" << endl;
	cout << "Faculty of Information Technology" << endl;
	cout << "Orientation Day 2026" << endl;
	cout << "Welcome!" << endl;
	cout << "2026" << endl;
	cout << "45" << endl;
	cout << 45 * 3 << endl;
	cout << 1000 + 500 - 250 << endl;
	cout << "Total Fee" << 45000 + 9000 << endl;

	
}


// Task  #02
#include <iostream>
using namespace std;
int main()
{
	cout << "Part A" << endl;
	// (;) was not there
	cout << "Orientation Day" << endl;
	// (<<)was not there
	cout << "Total students: " << 450 << endl;
	cout << "Seats left: " << 500 - 450 << endl;
	// ("") was not there
	cout << "Have a nice day" << endl;
		

	cout << "Plan B:" << endl;
	// (()) was not there
	cout << "Average: " << (60+80+70)/3 << endl;

		return 0;
}


 //Task  #03
#include <iostream>
using namespace std;
int main()
{
	cout << "Expression 1: " << 10 + 5 *2 << endl;
	cout << "Expression 2: " << (10 + 5)* 2 << endl;
	cout << "Expression 3: " << 20 - 5 - 3 << endl;
	cout << "Expression 4: " << 100 / 7 << endl;
	cout << "Expression 5: " << 100 % 7 << endl;
	cout << "Expression 6: " << 2 * (3 + 8 /4 - 1) << endl;
}


// Task #04
#include <iostream>
using namespace std;
int main()
{
	int rollno = 1045;
	int semester = 1;
	char section = 'B';
	double cgpa = 3.5;
	int totalFee = 45000;
	int feePaid = 20000;
	cout << "Roll No:" << rollno << endl;
	cout << "Semester " << semester << endl;
	cout << "Section:   " << section <<  endl;
	cout << "CGPA" << cgpa << endl;
	cout << "Total Fee: " << totalFee << endl;
	cout << "Fee Paid: " << feePaid << endl;

	semester = semester + 1;
	feePaid = feePaid + 5000;

	int remainingFee = totalFee - feePaid;
	int percentagefee = feePaid * 100 / totalFee;

	cout << "Semester: " << semester << endl;
	cout << "Fee Paid: " << feePaid << endl;
	cout << "Remaining Fee: " << remainingFee << endl;
	cout << "Percentage Paid: " << percentagefee << endl;

	return 0;
}


// Task  #05
#include <iostream>
using namespace std;
int main()
{
	int VariableAge;
	int CreditHours;
	int FeePerCreditHour;
	cout << "What is the age " << endl;
	cin >> VariableAge;
	cout << "What are the credit hours" << endl;
	cin >> CreditHours;
	cout << "What is the Fee per cradit hour" << endl;
	cin >> FeePerCreditHour;
	
	int TotalFee = CreditHours * FeePerCreditHour;
	

	cout << "Total Fee: " << TotalFee << endl;
	TotalFee = TotalFee - 2000;
	cout << "Total Fee after discount: " << TotalFee << endl;

	int birthYear = 2026 - VariableAge;
	int yearTurn25 = birthYear + 25;
	cout << " Age & Year Details" << endl;
	cout << "Year of Birth: " << birthYear << endl;
	cout << "Year when student will turn 25: " << yearTurn25 << endl;
}


// Task #06
#include <iostream>
using namespace std;
int main()
{
	int price;
	int quantity;
	cout << "Enter Price " << endl;
	cin >> price;
	cout << "Enter Quantity " << endl;
	cin >> quantity;

	int total = price * quantity;
	double tax = total * 5 / 100;
	double GrandTotal = total + tax;

	cout << "The total is: "<< total << endl;
	cout << "the tax is: "<< tax << endl;
	cout << "the grand total is:  "<< GrandTotal << endl;

	return 0;
}

